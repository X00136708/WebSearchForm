webpackHotUpdate("static\\development\\pages\\news.js",{

/***/ "./pages/news.js":
/*!***********************!*\
  !*** ./pages/news.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return news; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/isomorphic-unfetch/browser.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "H:\\Documents\\X00136708\\Year 3\\Semester 5\\Web\\Next\\hello\\pages\\news.js";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var news =
/*#__PURE__*/
function (_React$Components) {
  _inherits(news, _React$Components);

  function news(props) {
    var _this;

    _classCallCheck(this, news);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(news).call(this, props));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "setNewsSource", function (input) {
      _this.setState({
        newsSource: input
      });
    });

    _this.state = {
      newsSource: "",
      articles: []
    };
    return _this;
  }

  _createClass(news, [{
    key: "render",
    value: function render() {
      if (this.state.articles.length == 0) {
        this.state.articles = this.props.articles;
      }

      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-1862596225",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(SearchForm, {
        setNewsSource: this.setNewsSource,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
        className: "jsx-1862596225",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 42
        },
        __self: this
      }, "News from ", this.state.newsSource.split("-").join(" ")), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
        className: "jsx-1862596225",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }, this.state.articles.map(function (article, index) {
        return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", {
          key: index,
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("h3", {
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 53
          },
          __self: this
        }, article.title), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-1862596225" + " " + "author",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 55
          },
          __self: this
        }, article.author, " ", article.publishedAt), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
          src: article.urlToImage,
          alt: "article image",
          className: "jsx-1862596225" + " " + "img-article",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 57
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 59
          },
          __self: this
        }, article.description), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 61
          },
          __self: this
        }, article.content), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("p", {
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/story",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
          className: "jsx-1862596225",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          },
          __self: this
        }, "Read More"))));
      })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
        styleId: "1862596225",
        css: "\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkg6XFxEb2N1bWVudHNcXFgwMDEzNjcwOFxcWWVhciAzXFxTZW1lc3RlciA1XFxXZWJcXE5leHRcXGhlbGxvXFxwYWdlc1xcbmV3cy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUF1RWUiLCJmaWxlIjoiSDpcXERvY3VtZW50c1xcWDAwMTM2NzA4XFxZZWFyIDNcXFNlbWVzdGVyIDVcXFdlYlxcTmV4dFxcaGVsbG9cXHBhZ2VzXFxuZXdzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtdW5mZXRjaCc7XHJcblxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIG5ld3MgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnRzIHtcclxuXHJcblxyXG5cdGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcblx0XHRzdXBlcihwcm9wcylcclxuXHRcdHRoaXMuc3RhdGUgPSB7XHJcblx0XHRuZXdzU291cmNlOiBcIlwiLFxyXG5cdFx0YXJ0aWNsZXM6IFtdXHJcblxyXG5cdFx0fVxyXG5cclxuXHR9XHJcblx0c2V0TmV3c1NvdXJjZSA9IChpbnB1dCkgPT4ge1xyXG5cdFx0dGhpcy5zZXRTdGF0ZSh7XHJcblx0XHRcdG5ld3NTb3VyY2U6IGlucHV0XHJcblx0XHR9KVxyXG5cdH1cclxuXHJcblxyXG5cdHJlbmRlcigpIHtcclxuXHJcblxyXG5cdFx0aWYgKHRoaXMuc3RhdGUuYXJ0aWNsZXMubGVuZ3RoID09IDApIHtcclxuXHJcblx0XHRcdHRoaXMuc3RhdGUuYXJ0aWNsZXMgPSB0aGlzLnByb3BzLmFydGljbGVzO1xyXG5cclxuXHRcdH1cclxuXHJcblxyXG5cclxuXHRyZXR1cm4gKFxyXG5cclxuXHRcdDxkaXY+XHJcblx0XHQ8U2VhcmNoRm9ybSBzZXROZXdzU291cmNlPXt0aGlzLnNldE5ld3NTb3VyY2V9Lz5cclxuXHJcblxyXG5cdFx0PGgzPk5ld3MgZnJvbSB7dGhpcy5zdGF0ZS5uZXdzU291cmNlLnNwbGl0KFwiLVwiKS5qb2luKFwiIFwiKX08L2gzPlxyXG5cclxuXHRcdFx0PGRpdj5cclxuXHJcblxyXG5cclxuXHRcdFx0e1xyXG5cdFx0XHRcdHRoaXMuc3RhdGUuYXJ0aWNsZXMubWFwKChhcnRpY2xlLCBpbmRleCkgPT4gKFxyXG5cclxuXHRcdFx0XHQ8c2VjdGlvbiBrZXk9e2luZGV4fT5cclxuXHJcblx0XHRcdFx0PGgzPnthcnRpY2xlLnRpdGxlfTwvaDM+XHJcblxyXG5cdFx0XHRcdDxwIGNsYXNzTmFtZT1cImF1dGhvclwiPnthcnRpY2xlLmF1dGhvcn0ge2FydGljbGUucHVibGlzaGVkQXR9PC9wPlxyXG5cclxuXHRcdFx0XHQ8aW1nIHNyYz17YXJ0aWNsZS51cmxUb0ltYWdlfSBhbHQ9XCJhcnRpY2xlIGltYWdlXCIgY2xhc3NOYW1lPVwiaW1nLWFydGljbGVcIj48L2ltZz5cclxuXHJcblx0XHRcdFx0PHA+e2FydGljbGUuZGVzY3JpcHRpb259PC9wPlxyXG5cclxuXHRcdFx0XHQ8cD57YXJ0aWNsZS5jb250ZW50fTwvcD5cclxuXHJcblx0XHRcdFx0PHA+PExpbmsgaHJlZj1cIi9zdG9yeVwiPjxhPlJlYWQgTW9yZTwvYT48L0xpbms+PC9wPlxyXG5cclxuXHRcdFx0XHQ8L3NlY3Rpb24+XHJcblxyXG5cdFx0XHRcdCkpXHJcblx0XHRcdH1cclxuXHJcblx0XHRcdDwvZGl2PlxyXG5cclxuXHRcdFx0PHN0eWxlIGpzeD57YFxyXG5cclxuXHRcdFx0LyogbG9jYWwgQ1NTIGdvZXMgaGVyZSAqL1xyXG5cclxuXHRcdFx0YH08L3N0eWxlPlxyXG5cclxuXHRcdDwvZGl2PlxyXG5cclxuXHQpO1xyXG5cclxufVxyXG5cclxuXHJcblxyXG5zdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKCkge1xyXG5cdGNvbnN0IG5ld3NTb3VyY2UgPSBcInRoZS1pcmlzaC10aW1lc1wiO1xyXG5cdGNvbnN0IGFwaUtleSA9IFwiNmFkMzc0NzQxMTg0NDIwNTg1ZDlmZmM4NzdmMjVhMzlcIjtcclxuXHRjb25zdCB1cmwgPSBgaHR0cHM6Ly9uZXdzYXBpLm9yZy92Mi90b3AtaGVhZGxpbmVzP3NvdXJjZXM9JHtuZXdzU291cmNlfSZhcGlLZXk9JHthcGlLZXl9YDtcclxuXHRjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG5cdGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG5cdFxyXG5cclxuXHRyZXR1cm4ge1xyXG5cclxuXHRcdGFydGljbGVzOiBkYXRhLmFydGljbGVzXHJcblxyXG5cdH1cclxuXHJcbn1cclxuXHJcblx0YXN5bmMgY29tcG9uZW50RGlkVXBkYXRlKHByZXZQcm9wcywgcHJldlN0YXRlKSB7XHJcblxyXG5cclxuXHJcblx0XHRjb25zb2xlLmxvZyhgdXBkYXRlIG5ld3M6ICR7dGhpcy5zdGF0ZS5uZXdzU291cmNlfWApO1xyXG5cclxuXHJcblxyXG5cdFx0XHRpZiAodGhpcy5zdGF0ZS5uZXdzU291cmNlICE9PSBwcmV2U3RhdGUubmV3c1NvdXJjZSkge1xyXG5cclxuXHRcdFx0XHRjb25zdCBhcGlLZXkgPSAnNmFkMzc0NzQxMTg0NDIwNTg1ZDlmZmM4NzdmMjVhMzknO1xyXG5cdFx0XHRcdGNvbnN0IHVybCA9IGBodHRwczovL25ld3NhcGkub3JnL3YyL3RvcC1oZWFkbGluZXM/c291cmNlcz0ke3RoaXMuc3RhdGUubmV3c1NvdXJjZX0mYXBpS2V5PSR7YXBpS2V5fWA7XHJcblx0XHRcdFx0Y29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuXHRcdFx0XHRjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuXHRcdFx0XHR0aGlzLnN0YXRlLmFydGljbGVzID0gZGF0YS5hcnRpY2xlcztcclxuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHRoaXMuc3RhdGUpO1xyXG5cclxuXHRcdFx0fVxyXG5cclxuXHR9XHJcblxyXG59Il19 */\n/*@ sourceURL=H:\\Documents\\X00136708\\Year 3\\Semester 5\\Web\\Next\\hello\\pages\\news.js */",
        __self: this
      }));
    }
  }, {
    key: "componentDidUpdate",
    value: function () {
      var _componentDidUpdate = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(prevProps, prevState) {
        var apiKey, url, res, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                console.log("update news: ".concat(this.state.newsSource));

                if (!(this.state.newsSource !== prevState.newsSource)) {
                  _context.next = 12;
                  break;
                }

                apiKey = '6ad374741184420585d9ffc877f25a39';
                url = "https://newsapi.org/v2/top-headlines?sources=".concat(this.state.newsSource, "&apiKey=").concat(apiKey);
                _context.next = 6;
                return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

              case 6:
                res = _context.sent;
                _context.next = 9;
                return res.json();

              case 9:
                data = _context.sent;
                this.state.articles = data.articles;
                this.setState(this.state);

              case 12:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function componentDidUpdate(_x, _x2) {
        return _componentDidUpdate.apply(this, arguments);
      };
    }()
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var newsSource, apiKey, url, res, data;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                newsSource = "the-irish-times";
                apiKey = "6ad374741184420585d9ffc877f25a39";
                url = "https://newsapi.org/v2/top-headlines?sources=".concat(newsSource, "&apiKey=").concat(apiKey);
                _context2.next = 5;
                return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url);

              case 5:
                res = _context2.sent;
                _context2.next = 8;
                return res.json();

              case 8:
                data = _context2.sent;
                return _context2.abrupt("return", {
                  articles: data.articles
                });

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function getInitialProps() {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return news;
}(react__WEBPACK_IMPORTED_MODULE_2___default.a.Components);


    (function (Component, route) {
      if(!Component) return
      if (false) {}
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/news")
  
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=news.js.219479e7289112ea8dff.hot-update.js.map