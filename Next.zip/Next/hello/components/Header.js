const Header = () => (
<div>
	<p>Header</p>
</div>
)
export default Header;