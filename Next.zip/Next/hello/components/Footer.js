const Footer = () => (
<div>
<p>Footer</p>
</div>

)
export default Footer;