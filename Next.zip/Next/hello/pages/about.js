import Nav from '../components/Nav'
import Layout from '../components/myLayout'
import Footer from '../components/Footer'
const About = props => (
  <Layout>
  
    <h1>Batman TV Shows</h1>

  </Layout>
  
)

export default About