import Link from 'next/link';
import fetch from 'isomorphic-unfetch';



export default class news extends React.Component {


	constructor(props) {
		super(props)
		this.state = {
		newsSource: "",
		articles: []

		}

	}
	setNewsSource = (input) => {
		this.setState({
			newsSource: input
		})
	}


	render() {


		if (this.state.articles.length == 0) {

			this.state.articles = this.props.articles;

		}



	return (

		<div>
		<SearchForm setNewsSource={this.setNewsSource}/>


		<h3>News from {this.state.newsSource.split("-").join(" ")}</h3>

			<div>



			{
				this.state.articles.map((article, index) => (

				<section key={index}>

				<h3>{article.title}</h3>

				<p className="author">{article.author} {article.publishedAt}</p>

				<img src={article.urlToImage} alt="article image" className="img-article"></img>

				<p>{article.description}</p>

				<p>{article.content}</p>

				<p><Link href="/story"><a>Read More</a></Link></p>

				</section>

				))
			}

			</div>

			<style jsx>{`

			/* local CSS goes here */

			`}</style>

		</div>

	);

}



static async getInitialProps() {
	const newsSource = "the-irish-times";
	const apiKey = "6ad374741184420585d9ffc877f25a39";
	const url = `https://newsapi.org/v2/top-headlines?sources=${newsSource}&apiKey=${apiKey}`;
	const res = await fetch(url);
	const data = await res.json();
	

	return {

		articles: data.articles

	}

}

	async componentDidUpdate(prevProps, prevState) {



		console.log(`update news: ${this.state.newsSource}`);



			if (this.state.newsSource !== prevState.newsSource) {

				const apiKey = '6ad374741184420585d9ffc877f25a39';
				const url = `https://newsapi.org/v2/top-headlines?sources=${this.state.newsSource}&apiKey=${apiKey}`;
				const res = await fetch(url);
				const data = await res.json();
				this.state.articles = data.articles;
				this.setState(this.state);

			}

	}

}